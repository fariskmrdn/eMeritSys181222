<?php

include 'includes/config.php';
session_start();
$redirect = "dashboard.php";
if (!isset($_SESSION['email'])) {
  header("Location: index.php");
} else {
  $username = $_SESSION['email'];
}

$sql1 = "SELECT * FROM student WHERE email = '" . $username . "'";
$query1 = mysqli_query($con, $sql1);
$fetch1 = mysqli_fetch_array($query1);

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="includes/style.css">
  <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
  <link rel="manifest" href="/site.webmanifest">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
  <title>Dashboard eMerit Sys</title>
</head>

<body>
  <?php require_once('includes/sidebar.php'); ?>

  <section class="home-section">
    <div class="text">Papan Pemuka eMeritSys</div>

    <div class="row container ms-1 justify-content-md-evenly p-2 col-xl-12 col-md-5 col-sm-2">
      <div class="card p-3 col-xl-10 col-md-5 col-sm-3 bg-success bg-opacity-25" style="width: 18rem; border-radius: 12px;">
        <div class="card-body">
          <center>
            <i class="fal fa-user-clock fs-1"></i>
            <p class="fs-4">Mata Merit Saya</p>
            <p class="fs-1 text-success"><strong><?= $fetch1['merit_point']; ?></strong></p>
          </center>
        </div>
      </div>

      <div class="card p-3 col-xl-10 col-md-5 col-sm-1 bg-danger bg-opacity-25" style="width: 18rem; border-radius: 12px;">
        <div class="card-body p-3">
          <center>
          <i class="fal fa-exclamation-triangle fs-1"></i>
            <p class="fs-4">Mata DeMerit Saya (Saman)</p>
            <p class="fs-1 text-danger"><strong><?= $fetch1['demerit']; ?></strong></p>
          </center>
        </div>
      </div>
    </div>

    <div class="container p-3 bg-light mt-4 col-xl-9" style="border-radius: 50px; box-shadow:5px 5px 4px #a3a3a3;">
      <p class="h3 p-3">Profil Saya</p>
      <table class="table table-hover">
        <tr>
          <td class="tbltext text-uppercase">Nama Pelajar</td>
          <!-- <td></td> -->
          <td class=""><?= $fetch1['full_name']; ?></td>
        </tr>
        <tr>
          <td class="tbltext text-uppercase"> No. Kad Pengenalan</td>
          <!-- <td></td> -->
          <td><?= $fetch1['nric']; ?></td>
        </tr>
        <tr>
          <td class="tbltext text-uppercase">No. Matrix</td>
          <!-- <td></td> -->
          <td><?= $fetch1['matrixno']; ?></td>
        </tr>
        <tr>
          <td class="tbltext text-uppercase">Emel</td>
          <!-- <td></td> -->
          <td><?= $fetch1['email']; ?></td>
        </tr>
        <tr>
          <td class="tbltext text-uppercase">Jabatan</td>
          <!-- <td></td> -->
          <td><?= $fetch1['department']; ?></td>
        </tr>
        <tr>
          <td class="tbltext text-uppercase">Program</td>
          <!-- <td></td> -->
          <td><?= $fetch1['programme']; ?></td>
        </tr>
        <tr>
          <td class="tbltext text-uppercase">Semester</td>
          <!-- <td></td> -->
          <td><?= $fetch1['semester']; ?></td>
        </tr>
        <tr>
          <td class="tbltext text-uppercase">Kohot</td>
          <!-- <td></td> -->
          <td><?= $fetch1['kohort']; ?></td>
        </tr>
      </table>
    </div>

    <div class="container-fluid p-3 bg-light col-xl-8 col-lg-8 col-md-5 col-sm-2 mt-5" style="border-radius:20px;">
      <p class="text-bg-primary p-3"><i class="fas fa-info-circle"></i> Sekiranya permohonan anda tidak mendapat respon, sila maklumkan kepada ketua program masing-masing untuk semakan</p>
      <p class="h4">Permohonan Mata Merit</p>
      <p class="lead">Senarai semak permohonan mata merit pelajar</p>

      <table class="table table-responsive col-xl-12 col-lg-10 col-m-5 col-sm-2">
        <tr>
          <td class="col-m-2 col-sm-2">Bil</td>
          <td class="col-m-2 col-sm-2">Nama Aktiviti</td>
          <td class="col-m-2 col-sm-2">Status</td>
        </tr>
        <?php 
        $showStatus = "";
        $bil = 1;
        $getReq = "SELECT * FROM claim_form WHERE nokp = ".$fetch1['nric']."";
        $execgetReq = mysqli_query($con,$getReq);
        while ($show = mysqli_fetch_array($execgetReq)) {
            echo "";
        ?>
        <tr>
            <td>
                <?php echo $bil++; ?>
            </td>
            <td>
                <?php echo $show['activity_name']; ?>
            </td>
            <td>
                <?php 
                if ($show['status'] == '1') {
                    $showStatus = "<p class='text-warning'>DALAM PROSES</p>";
                } elseif ($show['status'] == '2') {
                    $showStatus = "<p class='text-danger'>PERMOHONAN GAGAL</p>";
                } elseif  ($show['status'] == '3') {
                    $showStatus = "<p class='text-success'>PERMOHONAN BERJAYA</p>";
                }
                ?>
                <?php echo $showStatus; ?>
            </td>
        </tr>
        <?php "";}?>
      </table>
    </div>

    <footer class="bd-footer py-3 py-md-2 mt-3 ">
      <div class="container py-3 py-md-2 px-3 px-md-3">
        <div class="row">
          <div class="col-lg-5 mb-1">
            <ul class="list-unstyled small text-muted">
              <li class="mb-1">Projek Tahun Akhir Diploma Teknologi Sistem Pengurusan Pangkalan Data <br> dan Aplikasi Web</li>

            </ul>
          </div>
        </div>
      </div>
    </footer>
  </section>
  <!-- <div class="loader-wrapper">
    <span class="loader"><span class="loader-inner"></span></span>
  </div> -->

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  <script src="includes/script.js"></script>

</body>

</html>