<?php

include 'includes/config.php';
session_start();
$msg = "";
$redirect = "dashboard.php";
if (!isset($_SESSION['email'])) {
  header("Location: index.php");
} else {
  $username = $_SESSION['email'];
}

$sql1 = "SELECT * FROM student WHERE email = '" . $username . "'";
$query1 = mysqli_query($con, $sql1);
$fetch1 = mysqli_fetch_array($query1);

if (isset($_POST['submit'])) {
    $nric = $_POST['nric'];
    $activity_name = $_POST['activity_name'];
    $act_date = $_POST['activity_date'];
    $act_org = $_POST['organizer'];
    $act_location = $_POST['location'];
    $act_desc = $_POST['detail'];
    $act_merit = $_POST['claimed'];

    $regist = "INSERT INTO `claim_form` (`id`, `nokp`, `activity_name`, `activity_date`, `organizer`, `location`, `description`, `merit`)
    VALUES
    (NULL, '$nric', '$activity_name', '$act_date', '$act_org', '$act_location', '$act_desc', '$act_merit')";
    $execRegist = mysqli_query($con, $regist);

    if ($execRegist == TRUE) {
      echo "
      <script>
      window.alert('Permohonan berjaya dihantar!');
      window.location = 'view.php';
      </script>
      ";
    } else {
      echo "
      <script>
      window.alert('Permohonan gagal dihantar!');
      </script>
      ";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="includes/style.css">
  <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
  <link rel="manifest" href="/site.webmanifest">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>

  <title>Semak Permohonan</title>
</head>

<body>
  <?php require_once('includes/sidebar.php'); ?>
  <section class="home-section">
    
    <div class="text">Semak Permohonan Mata Merit <button class="btn btn-warning d-flex" onclick="window.location='dashboard.php'"><i class="fas fa-arrow-left"></i>&nbsp&nbspKembali</button></div>
    <div class="container-fluid p-3 bg-light col-xl-12 col-lg-10 col-m-5 col-sm-2">
      <p class="text-bg-primary p-3"><i class="fas fa-info-circle"></i> Sekiranya permohonan anda tidak mendapat respon, sila maklumkan kepada ketua program masing-masing untuk semakan</p>
      <p class="h4">Permohonan Mata Merit</p>
      <p class="lead">Senarai semak permohonan mata merit pelajar</p>

      <table class="table table-responsive col-xl-12 col-lg-10 col-m-5 col-sm-2">
        <tr>
          <td class="col-m-2 col-sm-2">Bil</td>
          <td class="col-m-2 col-sm-2">Nama Aktiviti</td>
          <td class="col-m-2 col-sm-2">Status</td>
        </tr>
        <?php 
        $showStatus = "";
        $bil = 1;
        $getReq = "SELECT * FROM claim_form WHERE nokp = ".$fetch1['nric']."";
        $execgetReq = mysqli_query($con,$getReq);
        while ($show = mysqli_fetch_array($execgetReq)) {
            echo "";
        ?>
        <tr>
            <td>
                <?php echo $bil++; ?>
            </td>
            <td>
                <?php echo $show['activity_name']; ?>
            </td>
            <td>
                <?php 
                if ($show['status'] == '1') {
                    $showStatus = "<p class='text-warning'>DALAM PROSES</p>";
                } elseif ($show['status'] == '2') {
                    $showStatus = "<p class='text-danger'>PERMOHONAN GAGAL</p>";
                } elseif  ($show['status'] == '3') {
                    $showStatus = "<p class='text-success'>PERMOHONAN BERJAYA</p>";
                }
                ?>
                <?php echo $showStatus; ?>
            </td>
        </tr>
        <?php "";}?>
      </table>
    </div>
    
  </section>



<!-- Modal -->
<!-- <button data-bs-toggle="modal" data-bs-target="#staticBackdrop"></button> -->
<!-- <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Adakah Anda Pasti ?</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <center><i class="h1 far fa-exclamation-triangle"></i></center><br>
        Adakah anda pasti ingin mengantar permohonan ini?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="button" class="btn btn-success" >Teruskan</button>
      </div>
    </div>
  </div>
</div> -->
</form>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  <script src="includes/script.js"></script>
  <script>
    
  </script>
</body>

</html>