<?php 


// // System information
// const APP_NAME = 'Sistem Pengurusan Mata Merit Pelajar';

// // System base URL
// const APP_URL = 'http://emeritsys.test';

// // Database info
// const DB_TYPE = 'mysql';
// const DB_HOST = '127.0.0.1';
// const DB_PORT = 3307;
// const DB_DATABASE = 'emeritsys';
// const DB_USER = 'root';
// const DB_PASSWORD = '';

// global $db;

// $db = getDatabase();


// // session_start();
$username = "root";
$servername = "127.0.0.1";
$password = "";
$db = "emeritsys";

$con = new mysqli($servername, $username, $password, $db);

if ($con->connect_error) {
    die("Sambungan gagal: ". $con->connect_error);
}

//echo "Sambungan berjaya";

?>