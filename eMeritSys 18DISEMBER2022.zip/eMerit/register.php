<?php

include 'includes/config.php';
session_start();
$redirect = "dashboard.php";
if (!isset($_SESSION['email'])) {
  header("Location: index.php");
} else {
  $username = $_SESSION['email'];
}

$activityID = $_GET['activity_id'];
$sql1 = "SELECT * FROM student WHERE email = '" . $username . "'";
$query1 = mysqli_query($con, $sql1);
$fetch1 = mysqli_fetch_array($query1);

$month = date('m');
$month_desc = date('M');
$year = date('Y');
$sqlcallactivity =
  "SELECT * FROM activity_list 
  WHERE MONTH(activity_date) = '$month' 
  AND YEAR(activity_date) = '$year'";

$fetchActivityID = "SELECT * FROM activity_list WHERE activity_id = " . $activityID . "";
$queryActivity = mysqli_query($con, $fetchActivityID);
$fetchbyID = mysqli_fetch_array($queryActivity);

$fetchsql = mysqli_query($con, $sqlcallactivity);

if (isset($_POST['daftar'])) {
  $activityID = $_POST['id_aktiviti'];
  $nric = $_POST['nokp'];
  $terms = $_POST['terms'];
  $insertQ = "INSERT INTO `activity_enrolled` (`activity_id`, `nric`, `terms`)
  VALUES ('$activityID', '$nric', '$terms')";
  $insertDB = mysqli_query($con, $insertQ);

 // $check = "SELECT * FROM activity_enrolled WHERE activity_id = ".$activityID.." AND nric =";
  // if () {

  // }

  if (!$insertDB) {
    echo
    "
    <script>
    window.alert('Pendaftaran Tidak Berjaya');
    window.location = 'activitylist.php';
    </script>
    ";
  } else {
    echo
    "
    <script>
    window.alert('Pendaftaran Berjaya');
    window.location = 'dashboard.php';
    </script>
    ";
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
  <link rel="manifest" href="/site.webmanifest">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>

  <title>Register <?php echo $fetchbyID['activity_name']; ?></title>
</head>

<body>
  <?php require_once('includes/sidebar.php'); ?>
  <section class="home-section">
    <div class="text">Daftar Aktiviti & Program</div>
    <div class="bg-light table-responsive">
      <p class="h4 p-4">Daftar Program (<?php echo $fetchbyID['activity_name']; ?>)</p>

      <form style="padding:1rem;" action="" method="post">
        <table class="table">
        <tr>
            <th>ID Aktiviti</th>
          </tr>
          <tr>
            <td>
              <input type="text" class="form-control w-100" 
              name="id_aktiviti" value="<?= $fetchbyID['activity_id'] ?>" 
              readonly style="border:0px;">
            </td>
          </tr>
          <tr>
            <th>Nama Bengkel</th>
          </tr>
          <tr>
            <td>
              <input style="border:0px;" type="text" class="form-control w-100" name="program" value="<?= $fetchbyID['activity_name'] ?>" readonly>
            </td>
          </tr>
          <tr>
            <th>Tarikh</th>
          </tr>
          <tr>
            <td>
              <input style="border:0px;" type="text" class="form-control" name="tarikh" value="<?= $fetchbyID['activity_date'] ?>" readonly>
            </td>
          </tr>
          <tr>
            <th>Penganjur</th>
          </tr>
          <tr>
            <td>
              <input style="border:0px;" type="text" class="form-control" name="penganjur" value="<?= $fetchbyID['organizer'] ?>" readonly>
            </td>
          </tr>
          <tr>
            <th>Tempat/Institusi</th>
          </tr>
          <tr>
            <td>
              <input style="border:0px;" type="text" class="form-control" name="institusi" value="<?= $fetchbyID['institution'] ?>" readonly>
            </td>
          </tr>
          <tr>
            <th>Mata Merit</th>
          </tr>
          <tr>
            <td>
              <input style="border:0px;" type="text" class="form-control" name="matamerit" value="<?= $fetchbyID['point'] ?>" readonly>
            </td>
          </tr>
        </table>
        <table class="table table-striped table-sm padding">
          <tr>
            <td colspan="3" class="h3 p-3" style="text-align:center;">MAKLUMAT PESERTA</td>
          </tr>
          <tr>
            <td>Nama Peserta</td>
          </tr>
          <tr>
            <td>
              <input style="border:0px;" type="text" class="form-control" name="nama_pelajar" value="<?= $fetch1['full_name'] ?>" readonly>
            </td>
          </tr>
          <tr>
            <td>No. Matriks</td>
          </tr>
          <tr>
            <td>
              <input style="border:0px;" type="text" class="form-control" name="no_matriks" value="<?= $fetch1['matrixno'] ?>" readonly>
            </td>
          </tr>
          <tr>
            <td>NRIC</td>
          </tr>
          <tr>
            <td>
              <input style="border:0px;" type="text" class="form-control" name="nokp" value="<?= $fetch1['nric'] ?>" readonly>
            </td>
          </tr>
          <tr>
            <td>Program</td>
          </tr>
          <tr>
            <td>
              <input style="border:0px;" type="text" class="form-control" name="program_pelajar" value="<?= $fetch1['programme'] ?>" readonly>
            </td>
          </tr>
          <tr>
            <td>Semester</td>
          </tr>
          <tr>
            <td>
              <input style="border:0px;" type="text" class="form-control" name="semester" value="<?= $fetch1['semester'] ?>" readonly>
            </td>
          </tr>
          <tr>
            <td class="p-3">
              <p><strong>Penafian :</strong></p>
              <input name="terms" type="checkbox" required value="1"> 
               Saya bersetuju untuk menyertai program yang akan diadakan pada ketetapan berikut dan akan memberikan komitmen
               penuh sepanjang program ini berlangsung. Sekiranya saya tidak menghabiskan kursus atau program ini, saya tidak akan
               mendapat mata merit aktiviti dan tidak akan melakukan sebarang tuntutan mata merit pada akhir program.
            </td>
          </tr>
          <tr>
            <td>
              <button class="btn btn-primary" type="submit" name="daftar">Daftar Program</button>
              <button class="btn btn-warning" onclick="window.location='activitylist.php'">Kembali Ke Paparan Aktiviti</button>
            </td>
          </tr>
        </table>
      </form>

    </div>
  </section>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  <script src="script.js"></script>
  <script>
    // $("#dashboard").click(function(){
    //   alert("Button is clicked!");
    // });
  </script>
</body>

</html>