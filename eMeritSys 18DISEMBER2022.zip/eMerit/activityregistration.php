<?php

include 'includes/config.php';
session_start();
$msg = "";
$redirect = "dashboard.php";
if (!isset($_SESSION['email'])) {
  header("Location: index.php");
} else {
  $username = $_SESSION['email'];
}

$sql1 = "SELECT * FROM student WHERE email = '" . $username . "'";
$query1 = mysqli_query($con, $sql1);
$fetch1 = mysqli_fetch_array($query1);

if (isset($_POST['submit'])) {
    $nric = $_POST['nric'];
    $activity_name = $_POST['activity_name'];
    $act_date = $_POST['activity_date'];
    $act_org = $_POST['organizer'];
    $act_location = $_POST['location'];
    $act_desc = $_POST['detail'];
    $act_merit = $_POST['claimed'];

    $regist = "INSERT INTO `claim_form` (`id`, `nokp`, `activity_name`, `activity_date`, `organizer`, `location`, `description`, `merit`)
    VALUES
    (NULL, '$nric', '$activity_name', '$act_date', '$act_org', '$act_location', '$act_desc', '$act_merit')";
    $execRegist = mysqli_query($con, $regist);

    if ($execRegist == TRUE) {
      echo "
      <script>
      window.alert('Permohonan berjaya dihantar!');
      window.location = 'view.php';
      </script>
      ";
    } else {
      echo "
      <script>
      window.alert('Permohonan gagal dihantar!');
      </script>
      ";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="includes/style.css">
  <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
  <link rel="manifest" href="/site.webmanifest">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <meta http-equiv="refresh" content="600">


  <title>Daftar Aktiviti Kendiri</title>
</head>

<body>
  <?php require_once('includes/sidebar.php'); ?>
  <section class="home-section">
    <form method="POST">
    <div class="text">Daftar Aktiviti Kendiri <button onclick="window.location='view.php';" class="btn btn-primary d-flex"><i class="fas fa-arrow-right" ></i>&nbsp&nbspSemak Permohonan Saya</button></div>
    <div class="container-fluid p-3 bg-light col-xl-12 col-lg-10 col-m-5 col-sm-2">
      <p class="text-bg-info p-3"><i class="fas fa-info-circle"></i> Sila isi semua seksyen yang diperlukan. Kegagalan mengisi maklumat yang diperlukan boleh membawa kepada kegagalan permohonan tuntutan merit.</p>
      <p class="h4">Borang Tuntutan Mata Merit Aktiviti</p>
      <p class="lead">SEKSYEN A - Maklumat Pelajar</p>

      <table class="table table-responsive col-xl-12 col-lg-10 col-m-5 col-sm-2">
        <tr>
          <td class="col-m-2 col-sm-2">
            <strong>Nama Pelajar :</strong>
            <p><input class="form-control" disabled type="text" value="<?= $fetch1['full_name'] ?>"></p>
            <p><strong>No. Kad Pengenalan :</strong></p>
            <p><input class="form-control" readonly type="text" name="nric" value="<?= $fetch1['nric'] ?>"></p>
            <p><strong>No. Matriks :</strong></p>
            <p><input class="form-control" disabled type="text" value="<?= $fetch1['matrixno'] ?>"></p>
            <p><strong>Emel :</strong></p>
            <p><input class="form-control" disabled type="text" value="<?= $fetch1['email'] ?>"></p>
            <p><strong>Jabatan - Program:</strong></p>
            <p><input class="form-control" disabled type="text" value="<?php echo "" . $fetch1['department'] . " - " . $fetch1['programme'] . ""; ?>"></p>
            <p><strong>Semester :</strong></p>
            <p><input class="form-control" disabled type="text" value="<?= $fetch1['semester'] ?>"></p>
          </td>
        </tr>
      </table>
    </div>
    <div class="container-fluid p-3 bg-light col-xl-12 col-lg-10 col-m-5 col-sm-2">
      <p class="lead">SEKSYEN B - Maklumat Aktiviti/Bengkel</p>

      <table class="table table-responsive col-xl-12 col-lg-10 col-m-5 col-sm-2">
        <tr>
          <td class="col-m-2 col-sm-2">
            <strong>Nama Aktiviti :</strong>
            <p>
              <input type="text" class="form-control" name="activity_name" required placeholder="Masukkan nama aktiviti yang disertai">
            </p>
            <p><strong>Tarikh :</strong></p>
            <p><input type="date" class="form-control" name="activity_date" required></p>
            <p>
              <strong>Penganjur :
                <p style="color:red; font-size:12px;"><i>* Contoh - Jabatan Hospitaliti</i></p>
              </strong>
            </p>
            <p><input type="text" class="form-control" name="organizer" required placeholder="Masukkan nama penganjur program"></p>
            <p>
              <strong>Lokasi/Institusi :
                <p style="color:red; font-size:12px;"><i>* Contoh - Kolej Vokasional Kuala Selangor</i></p>
              </strong>
            </p>
            <p><input type="text" class="form-control" name="location" required placeholder="Masukkan lokasi aktiviti anda"></p>
          </td>
        </tr>
      </table>
    </div>
    <div class="container-fluid p-3 bg-light col-xl-12 col-lg-10 col-m-5 col-sm-2">
      <p class="lead">SEKSYEN C - Tuntutan Mata Merit</p>

      <table class="table table-responsive col-xl-12 col-lg-10 col-m-5 col-sm-2">
        <tr>
          <td class="col-m-2 col-sm-2">
            <strong>Rumusan Aktiviti :</strong>
            <p>
              <textarea class="form-control" name="detail" required cols="30" rows="10" placeholder="Sila beri penerangan tentang aktiviti/bengkel yang telah dilalui."></textarea>
            </p>
            <p><strong>Tuntutan Mata Merit :</strong></p>
            <p><input type="number" class="form-control" name="claimed" required placeholder="Masukkan mata merit yang ingin dimohon (1-5)"></p>

          </td>
        </tr>
      </table>
    </div>
    <div class="container-fluid p-3 bg-light col-xl-12 col-lg-10 col-m-5 col-sm-2">
      <p class="lead">SEKSYEN D - Perakuan dan Pengesahan</p>

      <table class="table table-responsive col-xl-12 col-lg-10 col-m-5 col-sm-2">
        <tr>
          <td class="col-m-2 col-sm-2">
            <p>
            <p>1. Tuntutan mata merit kendiri ini akan diperhalusi dan diluluskan oleh Ketua Program masing-masing.</p>
            <p>2. Aktiviti yang dirasakan tidak bersesuaian <strong>TIDAK AKAN</strong> diluluskan (Contoh: Menghadiri kempen politik dsb).</p>
            <p>3. Kelulusan tuntutan mata merit dalam tempoh 14-30 hari waktu bekerja.</p>
            <p>4. Pelajar yang didapati membuat tuntutan merit palsu boleh dikenakan tindakan tatatertib melalui Unit Hal Ehwal Pelajar.</p>
            <p>
              <input type="checkbox" required> Saya <strong><?php echo $fetch1['full_name'] ?></strong>, no. kad pengenalan <strong><?php echo $fetch1['nric'] ?></strong>
              dengan ini memperakui bahawa tuntutan ini adalah sah dan saya bersedia menerima tindakan sewajarnya sekiranya bertindak memalsukan permohonan mata merit ini
              selaras dengan undang-undang Kolej Vokasional Kuala Selangor.
            </p>
            <p>
              <button class="btn btn-success" name="submit" ><i class="fas fa-arrow-right" ></i> Hantar Permohonan</button>
            </p>
            </p>
          </td>
        </tr>
      </table>
    </div>
  </section>



<!-- Modal -->
<!-- <button data-bs-toggle="modal" data-bs-target="#staticBackdrop"></button> -->
<!-- <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Adakah Anda Pasti ?</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <center><i class="h1 far fa-exclamation-triangle"></i></center><br>
        Adakah anda pasti ingin mengantar permohonan ini?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="button" class="btn btn-success" >Teruskan</button>
      </div>
    </div>
  </div>
</div> -->
</form>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  <script src="includes/script.js"></script>
  <script>
    
  </script>
</body>

</html>