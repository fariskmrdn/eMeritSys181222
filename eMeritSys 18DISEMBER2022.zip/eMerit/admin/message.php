<?php

include '../includes/config.php';
session_start();
$redirect = "dashboard.php";
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
} else {
    $username = $_SESSION['email'];
}

if (isset($_REQUEST['id'])) {
    $msgID = $_REQUEST['id'];
    $fetchMsg = "SELECT * FROM noticeboard WHERE noticeid = '$msgID'";
    $execMsg = mysqli_query($con, $fetchMsg);
    $msgs = mysqli_fetch_array($execMsg);
}


$sql1 = "SELECT * FROM admin WHERE email = '" . $username . "'";
$query1 = mysqli_query($con, $sql1);
$fetch1 = mysqli_fetch_array($query1);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">

    <!-- <meta http-equiv="refresh" content="20"> -->
    <title>Dashboard eMerit Sys</title>
</head>

<body>
    <style>
        body {
            background-color: #242F3F;
        }

        .loader-wrapper {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            background-color: #242f3f;
            display: flex;
            justify-content: center;
            align-items: center;

        }

        .loader {
            display: inline-block;
            width: 30px;
            height: 30px;
            position: relative;
            border: 4px solid #Fff;
            animation: loader 2s infinite ease;
        }

        .loader-inner {
            vertical-align: top;
            display: inline-block;
            width: 100%;
            background-color: #fff;
            animation: loader-inner 2s infinite ease-in;
        }

        @keyframes loader {
            0% {
                transform: rotate(0deg);
            }

            25% {
                transform: rotate(180deg);
            }

            50% {
                transform: rotate(180deg);
            }

            75% {
                transform: rotate(360deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        @keyframes loader-inner {
            0% {
                height: 0%;
            }

            25% {
                height: 0%;
            }

            50% {
                height: 100%;
            }

            75% {
                height: 100%;
            }

            100% {
                height: 0%;
            }
        }
    </style>
    <?php require_once('../includes/sidebar2.php'); ?>
    <section class="home-section">
        <div class="text">Peti Masuk</div>


        <div class="container-fluid p-3 bg-light col-xl-10" id="announce">
            <div>
                <button class="btn btn-secondary" onclick="window.location='inbox.php'"><i class="fa-solid fa-rotate-left"></i>&nbsp&nbspKembali ke peti masuk</button>
            </div>
            <div class="notice_board">
              
                <table>
                    <tr>
                        <td>
                            <p class="h4"><?=$msgs['headline']?></p>
                            <p style="font-size: 15px;">
                                <?=$msgs['announcer']?>
                                <br>
                                <?=$msgs['published_date']?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <?=$msgs['body']?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <footer class="bd-footer py-3 py-md-2 mt-3 ">
            <div class="container py-3 py-md-2 px-3 px-md-3">
                <div class="row">
                    <div class="col-lg-5 mb-1">
                        <ul class="list-unstyled small text-muted">
                            <li class="mb-1">Projek Tahun Akhir Diploma Teknologi Sistem Pengurusan Pangkalan Data <br> dan Aplikasi Web</li>

                        </ul>
                    </div>
                </div>
            </div>
        </footer>
    </section>
    <div class="loader-wrapper">
        <span class="loader"><span class="loader-inner"></span></span>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable({
                responsive:true
            });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>


    <script src="../includes/script.js"></script>

</body>

</html>