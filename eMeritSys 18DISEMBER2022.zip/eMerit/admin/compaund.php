<?php

include '../includes/config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';
session_start();
$redirect = "dashboard.php";
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
} else {
    $username = $_SESSION['email'];
}

$sql1 = "SELECT * FROM admin WHERE email = '" . $username . "'";
$query1 = mysqli_query($con, $sql1);
$fetch1 = mysqli_fetch_array($query1);

$getAllMerit = "SELECT * FROM demerit_act";
$getExec = mysqli_query($con, $getAllMerit);

if (isset($_REQUEST['nric'])) {
    $nric = $_REQUEST['nric'];
    $studentFind = "SELECT * FROM student WHERE nric = '$nric'";
    $find = mysqli_query($con, $studentFind);
    $view = mysqli_fetch_array($find);
}

if (isset($_POST['tambah'])) {
    $studentName = mysqli_real_escape_string($con, $_POST['nama']);
    $nokp = mysqli_real_escape_string($con, $_POST['ic']);
    $meritpoint = mysqli_real_escape_string($con, $_POST['merit']);
    $meritDetails = mysqli_real_escape_string($con, $_POST['keterangan']);
    $reportDate = mysqli_real_escape_string($con, $_POST['masa']);
    $reporter = mysqli_real_escape_string($con, $_POST['pelapor']);

    $addMerit = "INSERT INTO `demerit_record` (`nokp`,`details`,`reportDate`,`reporter`,`demerit_id`) VALUES ('$nokp','$meritDetails','$reportDate','$reporter','$meritpoint')";
    $execMerit = mysqli_query($con, $addMerit);

    if ($execMerit == TRUE) {
        $registMerit = "UPDATE student SET demerit = demerit + '1' WHERE nric = '$nokp'";
        $execRegist = mysqli_query($con, $registMerit);
        if ($execRegist == TRUE) {

            //PHPMailer
            $mail = new PHPMailer(true);

            $mail->isSMTP();
            $mail->Host = 'mail.fariskmrdn.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'emeritsys@fariskmrdn.com';
            $mail->Password = 'emeritsys2022';
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;

            $mail->setFrom('emeritsys@fariskmrdn.com');

            $mail->addAddress("" . $view['email'] . "");

            $mail->isHTML(true);

            $mail->Subject = "MAKLUMAN SAMAN TERKINI!";
            $mail->Body = "
            <h1 class='h1'>Anda telah menerima DeMerit/Saman</h1>
            <p>Adalah dimaklumkan bahawa pelajar, ".$view['full_name'].", no Kad Pengenalan ".$view['nric']."
            telah dikenakan DeMerit seperti keterangan dibawah.
            </p>
            <table class='table'>
            <tr>
                <td>Tarikh DeMerit</td>
                <td>:</td>
                <td>".$reportDate."</td>
            </tr>
            <tr>
                <td>Keterangan DeMerit</td>
                <td>:</td>
                <td>".$meritDetails."</td>
            </tr>
            </table>
            <p>
            Sila log masuk ke akaun eMeritSys anda untuk makluman lanjut. Sekian
            </p>
            ";
                

            $mail->send();

            echo "
        <script>
            window.alert('1 Kes berjaya ditambah untuk " . $studentName . "');
            window.location = 'demerit.php';
        </script>
        ";
        } else {
            echo "
            <script>
                window.alert('Penambahan gagal');
                window.location = 'compaund.php';
            </script>
            ";
        }
    } else {
        echo "
        <script>
            window.alert('Penambahan gagal');
            window.location = 'compaund.php';
        </script>
        ";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="manifest" href="/site.webmanifest">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">

    <!-- <meta http-equiv="refresh" content="20"> -->
    <title>Merit/DeMerit Sys</title>
</head>

<body>

    <?php require_once('../includes/sidebar2.php'); ?>
    <section class="home-section">
        <div class="text">DeMerit Distribution</div>
        <div class="container-fluid p-3 d-flex justify-content-center bg-light col-xl-8 col-md-5 col-sm-2" style="border-radius:20px;">
            <table class="table">
                <form method="POST">
                    <tr>
                        <th>Nama Pelajar</th>
                    </tr>
                    <tr>
                        <td>
                            <input type="text" class="form-control" value="<?= $view['full_name'] ?>" name="nama" style="border:none;" readonly>
                        </td>
                    </tr>
                    <tr>
                        <th>No. Kad Pengenalan</th>
                    </tr>
                    <tr>
                        <td>
                            <input type="text" class="form-control" value="<?= $view['nric'] ?>" name="ic" style="border:none;" readonly>
                        </td>
                    </tr>
                    <tr>
                        <th>Jenis DeMerit</th>
                    </tr>
                    <tr>
                        <td>
                            <select name="merit" class="form-control">
                                <?php

                              
                                while ($merit = mysqli_fetch_array($getExec)) {
                                    echo "";
                                ?>
                                    <option value="<?= $merit['id'] ?>"><?= $merit['details'] ?></option>
                                <?php echo "";
                                } ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Keterangan Siasatan</th>
                    </tr>
                    <tr>
                        <td>
                            <textarea name="keterangan" id="" cols="30" rows="10" class="form-control" placeholder="Pada jam 00:00, pelajar ini telah melakukan kesalahan ..."></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th>Masa Laporan</th>
                    </tr>
                    <tr>
                        <td>
                            <input type="datetime-local" name="masa" class="form-control">
                        </td>
                    </tr>
                    <tr>
                        <th>Pelapor</th>
                    </tr>
                    <tr>
                        <td>
                            <input type="text" name="pelapor" class="form-control" value="<?= $fetch1['full_name'] ?>" readonly style="border: none;">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <button class="btn btn-danger" name="tambah" onclick="return confirm('Adakah anda pasti ingin kes kepada <?= $view['full_name'] ?>');">Tambah DeMerit</button>
                        </td>
                    </tr>
                </form>
            </table>
        </div>



    </section>



    <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
    <script>
        $(document).ready(function() {
            $('#permohonan').DataTable({
                responsive: true
            });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

    <script src="../includes/script.js"></script>

</body>

</html>