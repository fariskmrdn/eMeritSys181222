<?php

include '../includes/config.php';
session_start();
$redirect = "dashboard.php";
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
} else {
    $username = $_SESSION['email'];
}

$sql1 = "SELECT * FROM admin WHERE email = '" . $username . "'";
$query1 = mysqli_query($con, $sql1);
$fetch1 = mysqli_fetch_array($query1);
$penasihat = $fetch1["penasihat"];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <!-- <meta http-equiv="refresh" content="5"> -->
    <title>Dashboard eMerit Sys</title>
</head>

<body>
    <style>
        body {
            background-color: #242F3F;
        }

        .loader-wrapper {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            background-color: #242f3f;
            display: flex;
            justify-content: center;
            align-items: center;

        }

        .loader {
            display: inline-block;
            width: 30px;
            height: 30px;
            position: relative;
            border: 4px solid #Fff;
            animation: loader 2s infinite ease;
        }

        .loader-inner {
            vertical-align: top;
            display: inline-block;
            width: 100%;
            background-color: #fff;
            animation: loader-inner 2s infinite ease-in;
        }

        @keyframes loader {
            0% {
                transform: rotate(0deg);
            }

            25% {
                transform: rotate(180deg);
            }

            50% {
                transform: rotate(180deg);
            }

            75% {
                transform: rotate(360deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        @keyframes loader-inner {
            0% {
                height: 0%;
            }

            25% {
                height: 0%;
            }

            50% {
                height: 100%;
            }

            75% {
                height: 100%;
            }

            100% {
                height: 0%;
            }
        }
    </style>
    <?php require_once('../includes/sidebar2.php'); ?>
    <section class="home-section">
        <div class="text">Tambah Program / Aktiviti</div>
        <div class="container-fluid p-3 bg-light">
            <table class="table table-responsive col-xl-12 col-lg-10 col-m-5 col-sm-2">
                <tr>
                    <td>
                        <p class="text-bg-info p-3">
                            <i class="fad fa-info-square"></i> Sila isikan maklumat program atau bengkel yang dikehendaki pada ruangan yang disediakan.
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p>
                            <strong>SEKSYEN A : Butiran Program</strong>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td class="fs-5">Nama Program / Bengkel</td>
                </tr>
                <tr>
                    <td>
                        <input type="text" class="form-control" placeholder="Masukkan nama program">
                    </td>
                </tr>
                <tr>
                    <td class="fs-5">Penganjur</td>
                </tr>
                <tr>
                    <td>
                        <input type="text" class="form-control" placeholder="Masukkan butiran penganjur">
                    </td>
                </tr>
                <tr>
                    <td class="fs-5">Institusi</td>
                </tr>
                <tr>
                    <td>
                        <input type="text" class="form-control" placeholder="Masukkan butiran institusi">
                    </td>
                </tr>
                <tr>
                    <td class="fs-5">Tarikh Pelaksanaan</td>
                </tr>
                <tr>
                    <td>
                        <input type="date" class="form-control" placeholder="Masukkan butiran penganjur">
                    </td>
                </tr>
                <tr>
                    <td class="fs-5">Mata Merit Aktiviti<p class="fst-italic text-danger" style="font-size: 12px;">* Sila rujuk garis panduan pemberian mata merit aktiviti pelajar</p></td>
                </tr>
                <tr>
                    <td>
                        <input type="number" min="1" max="5" class="form-control" placeholder="Masukkan mata merit aktiviti sahaja">
                    </td>
                </tr>
                <tr>
                    <td class="fs-5">No. Siri Sijil<p class="fst-italic text-danger" style="font-size: 12px;">* Sila rujuk garis panduan no. siri sijil</p></td>
                </tr>
                <tr>
                    <td>
                        <input type="number" class="form-control" placeholder="Masukkan no. siri sijil">
                    </td>
                </tr>
                <tr>
                    <td>
                        <p>
                            <strong>SEKSYEN B : PENGESAHAN PENDAFTARAN AKTIVITI / PROGRAM</strong>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="checkbox" name="confirm" class="form-check-input">&nbsp
                        Saya <strong><?php echo $fetch1['full_name'] ?></strong> dengan ini memperakui bahawa maklumat program serta butiran yang
                        telah didaftarkan adalah benar dan tepat. Bahawasanya, program ini juga telah diluluskan di peringkat Pengurusan Kolej Vokasional Kuala Selangor.
                    </td>
                </tr>
                <tr>
                    <td>
                        <button class="btn btn-success"><i class="fad fa-chevron-square-right"></i> Daftar Program</button>
                    </td>
                </tr>
            </table>
        </div>


        </div>
    </section>
    <div class="loader-wrapper">
        <span class="loader"><span class="loader-inner"></span></span>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script src="../includes/script.js"></script>

</body>

</html>