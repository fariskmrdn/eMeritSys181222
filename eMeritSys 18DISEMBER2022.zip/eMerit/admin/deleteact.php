<?php 

include '../includes/config.php';
session_start();

if (isset($_REQUEST['nric'])) {
    $nric = $_REQUEST['nric'];

    $deleteEnrolled = "DELETE FROM activity_enrolled WHERE nric = ".$nric."";
    $execDelete = mysqli_query($con, $deleteEnrolled);

    if ($execDelete == TRUE) {
        echo "
        <script>
            window.alert('Penyertaan peserta berjaya dipadam! (".$nric.")');
            window.location = 'list.php';
        </script>
        ";
    } else {
        echo "
        <script>
            window.alert('Error');
            window.location = 'list.php';
        </script>
        ";
    }
}

?>