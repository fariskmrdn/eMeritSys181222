<?php

session_start();
include '../includes/config.php';
$msg = "";

if (isset($_POST['login'])) {
  $username = mysqli_real_escape_string($con, $_POST['username']);
  $password = mysqli_real_escape_string($con, $_POST['password']);

  $sqlQ1 = "SELECT * FROM admin WHERE email = '".$username."' AND nric = '".$password."'";
  $query1 = mysqli_query($con, $sqlQ1);
  $Authentication = mysqli_num_rows($query1);
  $profile = mysqli_fetch_array($query1);

  if ($Authentication == 1) {
    $_SESSION['email'] = $username;
    echo "
    <script>
      window.alert('Log masuk berjaya. Selamat datang ".$profile['full_name']."');
      window.location = 'dashboard.php';
    </script>
    ";
  } else {
    $msg = "
    <p class='text-danger fs-6 lead' style='text-align:center;'>Emel atau kata laluan tidak sepadan!</p>
    ";
  }
}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Log masuk Sistem Pengurusan Markah Merit Pelajar - Kolej Vokasional Kuala Selangor">
    <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <title>KVKS eMerit Sys -  Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body style="background-color: #E4E9F7;">

    <div class="container mt-5 p-3 d-flex justify-content-center align-content-center col-xl-12 col-md-8 col-sm-2" style="background-color: white; border-radius: 20px;box-shadow:5px 5px 4px #a3a3a3;">
        <div class="row">

            <div class="col-xl-6">
                <div>
                    <img src="images/logo.png" class="img-fluid" alt="">
                </div>
            </div>

            <!-- <form method="post"> -->
            <div class="col col-xl-5 col-md-5 col-sm-1">
                <div class="display-5">Log Masuk</div>
                <div>Log Masuk Pentadbir</div>
                <div>
                    <hr>
                </div>
                <form method="post">
                    <div class="mb-3 p-2">
                        <label for="inputEmail" class="form-label"><strong>Emel*</strong><p><?=$msg?></p></label>
                        <input type="email" class="form-control" name="username" required placeholder="mail@example.com">
                    </div>
                    <div class="mb-3 p-2">
                        <label for="inputEmail" class="form-label"><strong>Kata Laluan*</strong></label>
                        <input type="password" class="form-control" name="password" required placeholder="Masukkan kata laluan di sini">
                    </div>
                    <div class="p-3 mb-3">
                        <button class="btn" name="login" style="background-color: #E0B0FF;">Log Masuk</button>
                    </div>
                </form>
            </div>

        </div>
    </div>

  
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>