<?php 

include '../includes/config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';
session_start();

if (isset($_REQUEST['nric'], $_REQUEST['activity_id'])) {

    $NRIC = $_REQUEST['nric'];
    $ACTID = $_REQUEST['activity_id'];
    $getStudentInfo = "SELECT * FROM student WHERE nric = ".$NRIC."";
    $execInfo = mysqli_query($con, $getStudentInfo);
    $find = mysqli_fetch_array($execInfo);

    $getInfoAct = "SELECT * FROM activity_list WHERE activity_id = ".$ACTID."";
    $execInfoAct = mysqli_query($con, $getInfoAct);
    $findAct = mysqli_fetch_array($execInfoAct);

    $addMerit = "UPDATE student SET merit_point = merit_point + ".$findAct['point']." WHERE nric = '$NRIC'";
    $runAdd = mysqli_query($con, $addMerit);

    $changeTerms = "UPDATE activity_enrolled SET terms = '2' WHERE nric = '$NRIC' AND activity_id = '$ACTID'";
    $runTerms = mysqli_query($con, $changeTerms);

    if ($runAdd && $runTerms == TRUE) {

         //PHPMailer
       $mail = new PHPMailer(true);

       $mail->isSMTP();
       $mail->Host = 'mail.fariskmrdn.com';
       $mail->SMTPAuth = true;
       $mail->Username = 'emeritsys@fariskmrdn.com';
       $mail->Password = 'emeritsys2022';
       $mail->SMTPSecure = 'ssl';
       $mail->Port = 465;
   
       $mail->setFrom('emeritsys@fariskmrdn.com'); 
   
       $mail->addAddress("".$find['email']."");
   
       $mail->isHTML(true);
   
       $mail->Subject = "TAMBAHAN MERIT AKTIVITI BERJAYA!";
       $mail->Body =  
       "Sukacita dimaklumkan bahawa mata merit bagi aktiviti ".$findAct['activity_name']." sebanyak ".$findAct['point']." mata merit.
       <br>
       Akaun eMeritSys anda mempunyai <b style='color:green;'>".$find['merit_point']."</b> mata merit dan <b style='color:red;'>".$find['demerit']."</b> saman
       <br>
       Terima kasih
       ";
   
       $mail->send();

        echo "
        <script>
        window.alert('Mata merit diluluskan!');
        window.location = 'list.php';
        </script>
        ";
    } else {
        echo "
        <script>
        window.alert('Wrong token!');
        window.location = 'list.php';
        </script>
        ";
    }

      
}