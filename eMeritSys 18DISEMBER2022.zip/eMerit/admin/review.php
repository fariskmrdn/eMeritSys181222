<?php

include '../includes/config.php';
session_start();
$redirect = "dashboard.php";
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
} else {
    $username = $_SESSION['email'];
}

$sql1 = "SELECT * FROM admin WHERE email = '" . $username . "'";
$query1 = mysqli_query($con, $sql1);
$fetch1 = mysqli_fetch_array($query1);

if (isset($_REQUEST['id'])) {
    $claimID = $_REQUEST['id'];
}
$getAllClaim = "SELECT * FROM claim_form INNER JOIN student ON claim_form.nokp = student.nric WHERE id = '$claimID'";
$execAllClaim = mysqli_query($con, $getAllClaim);
$fetchClaim = mysqli_fetch_array($execAllClaim);

if (isset($_POST['lulus'])) {
    $mataMerit = mysqli_real_escape_string($con, $_POST['merit']);
    $nric = mysqli_real_escape_string($con, $_POST['nric']);

    $SumQuery = "UPDATE student SET merit_point = merit_point + '$mataMerit' WHERE nric = '$nric'";
    $execSum = mysqli_query($con, $SumQuery);

    $statChange = "UPDATE claim_form SET status = '3' WHERE id = '$claimID'";
    $execStat = mysqli_query($con, $statChange);

    if ($execSum && $execStat) {
        echo "
        <script>
        window.alert('Permohonan berjaya diluluskan!');
        window.location = 'view.php';
        </script>
        ";
    } else {
        echo "
        <script>
        window.alert('Transaksi Gagal!');
        window.location = 'review.php';
        </script>
        ";
    }
}

if (isset($_POST['tolak'])) {
    $statChange = "UPDATE claim_form SET status = '2' WHERE id = '$claimID'";
    $execStat = mysqli_query($con, $statChange);

    if ($execStat == TRUE) {
        echo "
        <script>
        window.alert('Permohonan berjaya ditolak!');
        window.location = 'view.php';
        </script>
        ";
    } else {
        echo "
        <script>
        window.alert('Transaksi Gagal!');
        window.location = 'review.php';
        </script>
        ";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <!-- <meta http-equiv="refresh" content="5"> -->
    <title>Permohonan eMerit Sys</title>
</head>

<body>
    <style>
        body {
            background-color: #242F3F;
        }

        .loader-wrapper {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            background-color: #242f3f;
            display: flex;
            justify-content: center;
            align-items: center;

        }

        .loader {
            display: inline-block;
            width: 30px;
            height: 30px;
            position: relative;
            border: 4px solid #Fff;
            animation: loader 2s infinite ease;
        }

        .loader-inner {
            vertical-align: top;
            display: inline-block;
            width: 100%;
            background-color: #fff;
            animation: loader-inner 2s infinite ease-in;
        }

        @keyframes loader {
            0% {
                transform: rotate(0deg);
            }

            25% {
                transform: rotate(180deg);
            }

            50% {
                transform: rotate(180deg);
            }

            75% {
                transform: rotate(360deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        @keyframes loader-inner {
            0% {
                height: 0%;
            }

            25% {
                height: 0%;
            }

            50% {
                height: 100%;
            }

            75% {
                height: 100%;
            }

            100% {
                height: 0%;
            }
        }
    </style>
    <?php require_once('../includes/sidebar2.php'); ?>
    <section class="home-section">
        <div class="text">Permohonan Merit Pelajar<p><button onclick="window.location='view.php'" class="btn btn-primary"><i class="fas fa-undo-alt"></i> Kembali ke paparan permohonan</button></p></div>
        <div class="container-fluid p-3 bg-light col-xl-10" style="border-radius:25px;">
            <table class="table p-3">
                <form method="POST">
                <tr>
                    <td class="h3" colspan="2"><?php echo $fetchClaim['activity_name'] ?></td>
                </tr>
                <tr>
                    <th colspan="2" class="fs-5 p-3 bg-info">Butiran Pemohon</th>
                </tr>
                <tr>
                    <th>Nama Pemohon</th>
                </tr>
                <tr>
                    <td><?php echo $fetchClaim['full_name']; ?></td>
                </tr>
                <tr>
                    <th>No. Kad Pengenalan</th>
                </tr>
                <tr>
                    <td>
                    <input type="text" name="nric" value="<?php echo $fetchClaim['nric']; ?>" readonly style="border: none;">    
                    </td>
                </tr>
                <tr>
                    <th>No. Matriks</th>
                </tr>
                <tr>
                    <td><?php echo $fetchClaim['matrixno']; ?></td>
                </tr>
                <tr>
                    <th>Emel</th>
                </tr>
                <td><?php echo $fetchClaim['email']; ?></td>
                </tr>
                <tr>
                    <th>Program</th>
                </tr>
                <tr>
                    <td><?php echo $fetchClaim['programme']; ?> | <?php echo $fetchClaim['semester']; ?></td>
                </tr>
                <tr>
                    <th class="p-3 bg-warning" colspan="2">Butiran Permohonan Program / Bengkel</th>
                </tr>
                <tr>
                    <th>Nama Program/Bengkel</th>
                </tr>
                <tr>
                    <td><?php echo $fetchClaim['activity_name'] ?></td>
                </tr>
                <tr>
                    <th>Penganjur</th>
                </tr>
                <tr>
                    <td><?php echo $fetchClaim['organizer'] ?></td>
                </tr>
                <tr>
                    <th>Institusi/Lokasi Program</th>
                </tr>
                <tr>
                    <td><?php echo $fetchClaim['location'] ?></td>
                </tr>
                <tr>
                    <th>Maklumat Program</th>
                </tr>
                <tr>
                    <td><?php echo $fetchClaim['description'] ?></td>
                </tr>
                <tr>
                    <th>Tarikh Program</th>
                </tr>
                <tr>
                    <td><?php echo $fetchClaim['activity_date'] ?></td>
                </tr>
                <tr>
                    <th>Merit Yang Dimohon</th>
                </tr>
                <tr>
                    <td><input type="text" value="<?php echo $fetchClaim['merit'] ?>" class="form-control" style="border: none;" readonly name="merit"></td>
                </tr>
                <tr>
                    <td>
                        <button class="btn btn-success" name="lulus" onclick="return confirm('Anda pasti ingin meluluskan permohonan ini?');"><i class="fas fa-check"></i> LULUSKAN PERMOHONAN</button>
                        <button class="btn btn-danger" name="tolak"><i class="fas fa-times"></i> TOLAK PERMOHONAN</button>
                    </td>
                </tr>
                </form>
            </table>
        </div>



    </section>
    <div class="loader-wrapper">
        <span class="loader"><span class="loader-inner"></span></span>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script src="../includes/script.js"></script>

</body>

</html>