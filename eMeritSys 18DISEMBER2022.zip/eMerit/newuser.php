<?php

session_start();
include 'includes/config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';
// $msg = "";

if (isset($_POST['register'])) {
    $nama = mysqli_real_escape_string($con, $_POST['fullname']);
    $emel = mysqli_real_escape_string($con, $_POST['emel']);
    $nokp = mysqli_real_escape_string($con, $_POST['nokp']);
    $jabatan = mysqli_real_escape_string($con, $_POST['jabatan']);
    $program = mysqli_real_escape_string($con, $_POST['program']);
    $semester = mysqli_real_escape_string($con, $_POST['semester']);
    $kohot = mysqli_real_escape_string($con, $_POST['kohot']);

    $registAcc = "INSERT INTO `student` (`full_name`,`nric`,`email`,`department`,`programme`,`semester`,`kohort`)
    VALUES ('$nama','$nokp','$emel','$jabatan','$program','$semester','$kohot')";
    $execRegist = mysqli_query($con, $registAcc);

    if ($execRegist == TRUE) {
          //PHPMailer
       $mail = new PHPMailer(true);

       $mail->isSMTP();
       $mail->Host = 'mail.fariskmrdn.com';
       $mail->SMTPAuth = true;
       $mail->Username = 'emeritsys@fariskmrdn.com';
       $mail->Password = 'emeritsys2022';
       $mail->SMTPSecure = 'ssl';
       $mail->Port = 465;
   
       $mail->setFrom('emeritsys@fariskmrdn.com'); 
   
       $mail->addAddress("".$emel."");
   
       $mail->isHTML(true);
   
       $mail->Subject = "PENDAFTARAN AKAUN EMERIT SYS BERJAYA";
       $mail->Body =  
       "
       Pendaftaran akaun eMeritSys anda <strong style='color:green;'>berjaya didaftarkan</strong>. <br>
       Sila log masuk menggunakan emel anda dan <i>no. kad pengenalan</i> sebagai kata laluan. <br>
       - eMeritSys First Acc Registar
       ";
   
       $mail->send();

        echo "
        <script>
        window.alert('Pendaftaran eMeritSys berjaya! Sila semak emel anda. Sekiranya anda tidak menerima emel anda, sila periksa di ruangan SPAM');
        window.location = 'index.php';
        </script>
        ";
    } else {
        echo "
        <script>
        window.alert('Error');
        window.location = 'index.php';
        </script>
        ";
    }

}

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Log masuk Sistem Pengurusan Markah Merit Pelajar - Kolej Vokasional Kuala Selangor">
    <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="stylesheet" href="/includes/style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Pengguna kali pertama eMeritSys</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
</head>

<body style="background-color: #E4E9F7;">



    <div class="container mt-5 p-3 d-flex justify-content-center align-content-center col-xl-12 col-md-8 col-sm-2" style="background-color: white; border-radius: 20px;box-shadow:5px 5px 4px #a3a3a3;">
        <div class="row">

            <div class="col-xl-6">
                <div>
                    <img src="images/logo.png" class="img-fluid" alt="">
                </div>
            </div>

            <!-- <form method="post"> -->
            <div class="col col-xl-5 col-md-5 col-sm-1">
                <div class="display-5">Pengguna Kali Pertama</div>
                <div>Sila lengkapkan borang pengguna dibawah</div>
                <div>
                    <hr>
                </div>
                <form method="post">
                    <div class="mb-3 p-2">
                        <label for="inputEmail" class="form-label"><strong>Nama Pelajar</strong></label>
                        <input type="text" class="form-control" name="fullname" required placeholder="Cth : Ali bin Abu">
                    </div>
                    <div class="mb-3 p-2">
                        <label for="inputEmail" class="form-label"><strong>Emel</strong></label>
                        <input type="email" class="form-control" name="emel" required placeholder="Cth : example@test.com">
                    </div>
                    <div class="mb-3 p-2">
                        <label for="inputEmail" class="form-label"><strong>No. Kad Pengenalan</strong></label>
                        <input type="text" class="form-control" name="nokp" required placeholder="Cth : 010203104545 (tanpa -)">
                    </div>
                    <div class="mb-3 p-2">
                        <label for="inputEmail" class="form-label"><strong>Jabatan</strong></label>
                        <select name="jabatan" id="" class="form-control">
                            <option value="JABATAN TEKNOLOGI MAKLUMAT">JABATAN TEKNOLOGI MAKLUMAT</option>
                            <option value="JABATAN SENI REKA">JABATAN SENI REKA</option>
                            <option value="JABATAN HOSPITALITI">JABATAN HOSPITALITI</option>
                            <option value="JABATAN PERNIAGAAN">JABATAN PERNIAGAAN</option>
                        </select>
                    </div>
                    <div class="mb-3 p-2">
                        <label for="inputEmail" class="form-label"><strong>Program</strong></label>
                        <select name="program" id="" class="form-control">
                            <option value="TEKNOLOGI SISTEM PENGURUSAN PANGKALAN DATA & APLIKASI WEB">TEKNOLOGI SISTEM PENGURUSAN PANGKALAN DATA & APLIKASI WEB</option>
                            <option value="ANIMASI 3D">ANIMASI 3D</option>
                            <option value="BAKERI & PASTERI">BAKERI & PASTERI</option>
                            <option value="SENI KULINARI">SENI KULINARI</option>
                            <option value="PEMASARAN">PEMASARAN</option>
                            <option value="PERAKAUNAN">PERAKAUNAN</option>
                        </select>
                    </div>
                    <div class="mb-3 p-2">
                        <label for="inputEmail" class="form-label"><strong>Semester</strong></label>
                        <select name="semester" id="" class="form-control">
                            <option value="DIPLOMA VOKASIONAL MALAYSIA - SEMESTER 1">DIPLOMA VOKASIONAL MALAYSIA - SEMESTER 1</option>
                            <option value="DIPLOMA VOKASIONAL MALAYSIA - SEMESTER 2">DIPLOMA VOKASIONAL MALAYSIA - SEMESTER 2</option>
                            <option value="DIPLOMA VOKASIONAL MALAYSIA - SEMESTER 3">DIPLOMA VOKASIONAL MALAYSIA - SEMESTER 3</option>
                            <option value="DIPLOMA VOKASIONAL MALAYSIA - SEMESTER 4">DIPLOMA VOKASIONAL MALAYSIA - SEMESTER 4</option>
                        </select>
                    </div>
                    <div class="mb-3 p-2">
                        <label for="inputEmail" class="form-label"><strong>Kohot</strong></label>
                        <select name="kohot" id="" class="form-control">
                            <option value="2019">2019</option>
                            <option value="2020">2020</option>
                            <option value="2021">2021</option>
                            <option value="2022">2022</option>
                            <option value="2023">2023</option>
                            <option value="2024">2024</option>
                        </select>
                    </div>
                    <div class="mb-3 p-2">
                        <label for="inputEmail" class="form-label"><strong>PERAKUAN PENGGUNA</strong></label><br>
                        <input type="checkbox" class="form-check-input" required>
                        Maklumat yang didaftarkan adalah benar. Sekiranya maklumat yang diberikan adalah tidak tepat, saya akan menerima DeMerit.
                    </div>
                    <div class="p-3 mb-3">
                        <button class="btn btn-outline-success" name="register">Daftar Kali Pertama</button>
                    </div>
                </form>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</body>

</html>