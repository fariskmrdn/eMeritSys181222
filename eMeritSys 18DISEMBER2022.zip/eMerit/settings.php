<?php

include 'includes/config.php';
session_start();
$msg = "";
$redirect = "dashboard.php";
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
} else {
    $username = $_SESSION['email'];
}

$sql1 = "SELECT * FROM student WHERE email = '" . $username . "'";
$query1 = mysqli_query($con, $sql1);
$fetch1 = mysqli_fetch_array($query1);

if (isset($_POST['change'])) {
    $emel = mysqli_real_escape_string($con, $_POST['emel']);
    $updateQ = "UPDATE student SET email = '$emel' WHERE nric = '".$fetch1['nric']."'";
    $exec = mysqli_query($con, $updateQ);

    if ($exec == TRUE) {
        echo "
        <script>
            window.alert('Kemaskini akaun anda berjaya! Sila log masuk semula.');
            window.location = 'sessiondestroy.php';
        </script>
        ";
    } else {
        echo "
        <script>
            window.alert('Kemaskini akaun anda tidak berjaya!');
        </script>
        ";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="includes/style.css">
    <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>

    <title>My Setting</title>
</head>

<body>
    <?php require_once('includes/sidebar.php'); ?>
    <section class="home-section">
        <div class="text">Tetapan</div>
        <div class="container-fluid p-3 bg-light col-xl-12 col-lg-10 col-m-5 col-sm-2">
            <p class="h4">Tetapan Saya</p>
            <p class="lead">Maklumat Diri Pelajar</p>
            <p class="text-bg-warning p-3">* Sekiranya terdapat ralat pada maklumat diri pelajar, sila hubungi ketua program anda.</p>

            <table class="table table-responsive col-xl-12 col-lg-10 col-m-5 col-sm-2">
                <tr>
                    <td class="col-m-2 col-sm-2">
                        <strong>Nama Pelajar :</strong>
                        <p><?= $fetch1['full_name'] ?></p>
                        <p><strong>No. Kad Pengenalan :</strong></p>
                        <p><?= $fetch1['nric'] ?></p>
                        <p><strong>No. Matriks :</strong></p>
                        <p><?= $fetch1['matrixno'] ?></p>
                        <p><strong>Emel :</strong></p>
                        <form method="post">
                        <p><input type="text" name="emel" required class="form-control" value="<?= $fetch1['email'] ?>"></p>
                        <p><button type="submit" name="change" class="btn btn-danger" value="Kemaskini Email" onclick="return confirm('Adakah anda pasti untuk menukar emel ini?')"><i class="fal fa-envelope"></i> Kemaskini Emel</button>
                        </form>
                        <p><strong>Jabatan - Program:</strong></p>
                        <p><?php echo "".$fetch1['department']." - ".$fetch1['programme'].""; ?></p>
                        <p><strong>Semester :</strong></p>
                        <p><?= $fetch1['semester'] ?></p>
                    </td>
                </tr>
            </table>
        </div>
        <div class="container-fluid p-3 bg-light col-xl-12 col-lg-10 col-m-5 col-sm-2">
            <p class="h4">Konfigurasi Akaun</p>
            <form method="POST">
            <table class="table table-responsive col-xl-12 col-lg-10 col-m-5 col-sm-2">
                <tr>
                    <td class="col-m-2 col-sm-2">
                    Konfigurasi akaun anda hanya boleh dilakukan oleh pentadbir sistem sahaja. Sila hubungi pegawai berkenaan untuk tetapan semula sistem.
                    <p class="p-3">
                        <button class="btn btn-primary disabled"><i class="fal fa-key"></i> Klik untuk penetapan semula akaun</button>
                    </p>
                    </td>
                </tr>
                
            </table>
        </form>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script src="includes/script.js"></script>
    <script>
        // $("#daftar").click(function(){
        //   alert("Button is clicked!");
        // });
    </script>
</body>

</html>